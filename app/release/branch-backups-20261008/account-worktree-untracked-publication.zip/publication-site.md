# 公開案内サイトとアプリ内の入口

作成日：2026-10-07／状態：文案・サイトの下書き。公開版の方針とアプリ接続は未確定。

個人開発で更新できる1ページのHTMLを[website/](../website/README.md)へ保存する。
文案は`website/dist/index.html`。既存の[Play公開計画](google-play-publication-workflow.md)に沿い、
外部フォームや独自の受付システムは設けず、サポートメール1つを基本にする。
2026-10-08の利用者指定により、サポート・プライバシー・安全相談の共通窓口を
`ponpoko361@gmail.com`とし、サイトの本文と`mailto:`リンクに反映した。
問い合わせ・削除・安全対応は、担当者が実行可能な手順を確定してから施行する。

## 実装から確認した事実

| 文案へ反映した内容 | 根拠 |
| --- | --- |
| 認証保存の暗号化、アカウント情報の保持 | `app/src/main/java/io/github/ponpokoo/mastodonclient/core/security/SecureAuthStore.kt`・[開発ガイド](project-setup.md) |
| 下書き・通常設定は認証情報と同じ暗号化領域ではない | `core/preferences/UserPreferencesStore.kt`・`data/local/DraftMediaDataSource.kt`（いずれも上記Javaソースルート配下） |
| 登録削除で対象の下書き・添付・設定・履歴・通知を回収し、アプリ共通設定を保持する | `data/repository/DefaultAuthRepository.kt`の`removeConfirmedAccount`・[UI仕様](ui-guidelines.md#登録済みアカウントの管理)・[ADR 0014](adr/0014-account-local-data-removal.md) |
| Push解除失敗時の暗号化保存・再試行 | [購読管理](push-settings.md#保存解除再開) |
| Firebase設定時の起動時トークン取得。Pushオフでも通信があり得る | [Android受信](push-reception.md#fcmトークン取得と同期) |
| Relayの管理情報・暗号文、TTL最大24時間、無期限の墓標 | [現在のWorkers実装](../relay/workers/README.md#配送と保存)・[通信契約](relay-protocol.md) |
| DBと認証・Push情報はバックアップ除外。下書き・設定を全て除外していない | `app/src/main/res/xml/backup_rules.xml`・`data_extraction_rules.xml` |
| 投稿・利用者の報告は接続先サーバーへ送る | [報告の仕様](ui-guidelines.md#ミュートブロック報告) |

Cloudflare・Firebase・メール・サイトの実設定は本作業で監査していない。
現在の本番Relayは保存・fetch方式であり、採用済みハイブリッド方式への本番切替は未実施。
切替時は[採用仕様](../relay/workers/hybrid.md)に合わせ、暗号文保持の文案を改訂する。
墓標、プラットフォームのログ・バックアップ、問い合わせ保存期間等は公開前に確定する。
「収集なし」「ログアウト時に全て削除」「PushオフならGoogle通信なし」とは説明しない。

2026-10-08の登録削除実装により、所有者限定サイトのdraft-3にある「下書きは削除されません」は旧仕様となった。
次のサイト更新では対象アカウントの下書き・添付・設定・履歴・通知の削除と、共通設定保持・回収失敗時の再試行へ説明を更新する。
このアプリ実装変更ではサイトの配布は行っていない。

## アプリへの接続案（未実装）

- ログイン画面に利用規約・プライバシーのリンクを置き、同意前も読むことができる。
- 設定の「このアプリについて」から5つのアンカーと問い合わせ窓口を開く。
- 投稿作成・編集・返信・外部共有の入口で初回の規約同意を確認し、同意前にメディアをアップロードしない。
- 既存ログイン利用者にも適用する。同意は明示的な操作で取り、戻る・取消は同意としない。
- 同意した規約の版を端末に保存し、重要な変更では再確認する案。単純な文言修正で毎回要求しない。
- 規約同意、必要なデータ処理の説明・同意、Android通知権限をそれぞれの目的に沿って設計する。
- 外部共有で受けた本文・添付や既存下書きを、同意画面の取消やセッション切替で消失・誤送信させない。

公開URL・規約の版・問い合わせ先が確定するまで、所有者限定の下書きURLをアプリへ組み込まない。
同意保存・投稿入口・セッション境界の実装時は、[開発ガイド](project-setup.md)に沿って設計と検証を行う。
今回のサイト作成は、アプリ内リンク・同意・安全相談機能の実装完了を意味しない。

## 未確定情報と進め方

HTMLの`data-pending`と[サイトREADME](../website/README.md#公開前に埋める内容)に不足を記録する。
開発者名・安全担当者・対象年齢・Push提供方針・保存期間・削除受付方法を確定し、
下書きを正式な文書へ変更する。次にログイン不要の公開URLを確認し、アプリへ接続する。
PlayのData safety・削除要件・コンテンツ表示・安全基準の回答は、提出AABと実運用へ照合する。

## 公式資料

### 文案の簡潔化で参照した既存文書（2026-10-08）

- [PachliのPrivacy Policy](https://pachli.app/privacy/)：保存・送信・削除・連絡先を目的別に記す構成。
- [PachliのCSAE Policy](https://pachli.app/csae/)：禁止事項、サーバーへの報告、連絡先の示し方。
- [Mastodon for AndroidのPrivacy Policy](https://joinmastodon.org/android/privacy)：接続先サーバーのポリシーへの案内。

文章を転載せず、Nagisaの実装に沿って書き直した。Relay・FCMを利用するため、
他アプリの「情報を収集しない」等の宣言は採用していない。
暗号文の保存・解除済み記録、解除失敗時の認証情報、下書き・バックアップの扱いは残した。
本文・メタ情報から「個人開発」「開発者1人」等の運用規模の表現を除いた。
5つの参照先とメール窓口を維持し、未確定項目7件は末尾の開閉できる確認欄へまとめた。
規約の確定・アプリ内同意・正式公開を、この編集で完了扱いにはしない。

### Googleの要件

2026-10-07に参照したGoogleの要件。本文は実装に基づくNagisaの文案であり、Google文書の複製ではない。

- [User Data／プライバシー](https://support.google.com/googleplay/android-developer/answer/10144311?hl=en)
- [UGCと投稿前の同意](https://support.google.com/googleplay/android-developer/answer/9876937?hl=en)
- [子どもの安全基準](https://support.google.com/googleplay/android-developer/answer/14747720?hl=en)
- [アカウント削除](https://support.google.com/googleplay/android-developer/answer/13327111?hl=en)
- [Firebaseのデータ処理](https://firebase.google.com/support/privacy)

## 確認記録

2026-10-07：サイトのアンカー16参照・ID重複なし、同梱CSS、未確定表示8項目、
新規文書のローカル参照先、`git diff --check`を確認した。
ローカルHTTPプレビューは200を返し、案内本文を確認した。Codexへの表示要求はqueuedを返した。
ブラウザーでの外観・実スマートフォンでの表示確認は未実施。
サイト・文書のみの変更のため、Gradleビルド・Androidテストは行っていない。

Sitesへ静的ファイルだけを配布し、ネイティブの配置結果が`succeeded`であることを確認した。
確認用URL：[Nagisa ご利用案内](https://nagisa-guide.ponpokoo.chatgpt.site)。
初期状態の所有者限定アクセスを維持しているため、Play提出用の公開ポリシーURLにはまだ使わない。
配布ソース：`fd8cee6f90442516062a9edcc8a2e42646a7ffb0`（Sites専用リポジトリ）。
Androidリポジトリのコミットではない。実設定の監査、正式な文書の施行、アプリ内接続は未実施。

2026-10-08：指定された`ponpoko361@gmail.com`をプライバシー・安全相談・問い合わせの
3か所へ`mailto:`リンク付きで反映した。メールの未確定表示を取り除き、残る未確定項目は7項目。
アドレスとメールリンク、既存アンカー、差分を確認した。送受信の試験は行っていない。
更新したSitesの配布結果は`succeeded`。所有者限定アクセスと確認用URLを維持した。
更新ソース：`415197d1f6d1704efb08cfb48b2b5e2f8e9732de`（Sites専用リポジトリ）。
開発者名・安全担当者・保存期間等の確定、正式公開とアプリへの接続は引き続き未実施。

2026-10-08の簡潔化：HTMLのmain内テキスト（タグ・空白を除く）を4,894文字から2,765文字へ
約44%削減した。小見出しは17個から6個、段落は47個から20個に整理した。
既存アンカー、メールリンク3か所、未確定項目7件、同梱CSS、運用規模の文言の削除と差分を確認した。
配布結果は`succeeded`。所有者限定の下書きを維持し、外観のブラウザー目視確認は今回も未実施。
更新ソース：`4c22bc01be705725e485a71ce203550294f0a573`（Sites専用リポジトリ）。
